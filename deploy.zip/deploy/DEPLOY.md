# Deploy — Pattern Studio (license email via Resend, watermark off)

Repo: kleequsa/tools · branch: main · live: https://tools.kleeq.com/

## What changed
- `_worker.js` — NEW `POST /api/license`: license requests and export-gate emails are sent to connect@kleeq.com through Resend (secret `RESEND_API_KEY`). Verify kleeq.com in Resend and adjust `FROM` in `_worker.js` if needed. Until the secret is set, the form falls back to mailto:.
- `pattern-studio/index.html` — license form and export gate POST to `/api/license`; watermark removed (PNG-only live export)
- `pattern-studio/index.html` — live site exports PNG only (one Download PNG button; SVG / Copy / Engrave layers / batch hidden and routed to PNG)
- `pattern-studio/index.html` — Premium lock enforced on the live host: no preview render, no SVG/PNG/copy/layers/batch export, ⌘S routed to the license sheet
- `pattern-studio/kleeq-pattern-engine.js` — 53 Premium motif ids baked into `KLEEQ_PREMIUM` (they were only in local storage before); `?v=13` cache-bust
- `pattern-studio/` — NEW: Pattern Studio (index.html, kleeq-pattern-engine.js, kleeq-glyph-fields.js, kleeq-analytics.js, logo SVGs). Loads shared `../vendor/` support, Modernist css + bundle. Favicons included.
- `index.html` — hub: Pattern Studio card (PRIVATE · BETA), before KLEEQ Space
- `_worker.js` — `/pattern-studio` added to PROTECTED (Basic Auth, secret `PATTERN_PASSWORD`, optional `PATTERN_USER`)

## Steps
1. Copy this bundle over the repo root.
2. `npx wrangler secret put PATTERN_PASSWORD` (the path returns 503 until set).
   `npx wrangler secret put RESEND_API_KEY` (from resend.com → API Keys; domain kleeq.com must be verified there).
3. ```
   git add index.html _worker.js pattern-studio
   git commit -m "pattern-studio: license requests via Resend; watermark off"
   git push origin main
   ```
4. `npx wrangler deploy` from the repo root.
5. Purge Cloudflare cache; hard-refresh.
6. Smoke test: hub card → /pattern-studio/ prompts for password → loads, motif renders, Download SVG works, APPLICATOR TOOLS pill returns to hub.
