// KLEEQ tools — edge gate.
// Everything is served from static assets except paths listed in PROTECTED,
// which require HTTP Basic Auth. Set the secret once:
//     npx wrangler secret put CAMO_PASSWORD
//     npx wrangler secret put MIXLAB_PASSWORD
//     npx wrangler secret put PATTERN_PASSWORD
// Username is ignored unless the matching *_USER secret is also set.
//
// POST /api/license  — license requests and export-gate emails from Pattern Studio.
// Sent to INBOX via Resend (https://resend.com). Set once:
//     npx wrangler secret put RESEND_API_KEY
// FROM must be on a domain verified in Resend (e.g. tools@kleeq.com).
const INBOX = 'connect@kleeq.com';
const FROM = 'KLEEQ Tools <tools@kleeq.com>';
const PROTECTED = [
  { prefix: '/camo-studio', user: 'CAMO_USER', pass: 'CAMO_PASSWORD', realm: 'KLEEQ Camo Studio' },
  { prefix: '/mix-lab', user: 'MIXLAB_USER', pass: 'MIXLAB_PASSWORD', realm: 'KLEEQ Mix Lab' },
  { prefix: '/pattern-studio', user: 'PATTERN_USER', pass: 'PATTERN_PASSWORD', realm: 'KLEEQ Pattern Studio' }
];

const deny = (realm) => new Response('Sign in to open this KLEEQ tool.', {
  status: 401,
  headers: { 'WWW-Authenticate': 'Basic realm="' + realm + '", charset="UTF-8"', 'Cache-Control': 'no-store' }
});

const same = (a, b) => {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
};

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });

async function handleLicense(request, env) {
  if (request.method !== 'POST') return json({ error: 'POST only' }, 405);
  if (!env.RESEND_API_KEY) return json({ error: 'RESEND_API_KEY not configured' }, 503);
  let b; try { b = await request.json(); } catch (e) { return json({ error: 'bad json' }, 400); }
  const email = String(b.email || '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 200) return json({ error: 'bad email' }, 400);
  const gate = b.kind === 'gate';
  const subject = gate ? 'Pattern Studio export: ' + email : 'KLEEQ Premium license — ' + String(b.pattern || '').slice(0, 120);
  const rows = gate
    ? [['Email', email], ['Page', b.page]]
    : [['Pattern', b.pattern], ['Name', b.name], ['Company', b.company], ['Email', email], ['Intended use', b.use], ['Note', b.note], ['Page', b.page]];
  const text = rows.map(([k, v]) => k + ': ' + String(v ?? '').slice(0, 2000)).join('\n');
  const html = '<table style="font:14px/1.5 sans-serif">' + rows.map(([k, v]) => '<tr><td style="padding:4px 12px 4px 0;color:#666;vertical-align:top">' + k + '</td><td style="padding:4px 0;white-space:pre-wrap">' + esc(String(v ?? '').slice(0, 2000)) + '</td></tr>').join('') + '</table>';
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: FROM, to: [INBOX], reply_to: email, subject, text, html })
  });
  if (!r.ok) return json({ error: 'mail failed', detail: (await r.text()).slice(0, 300) }, 502);
  return json({ ok: true });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/license') return handleLicense(request, env);
    const rule = PROTECTED.find((r) => url.pathname === r.prefix || url.pathname.startsWith(r.prefix + '/'));
    if (rule) {
      const want = env[rule.pass];
      if (!want) return new Response('Password not configured: run wrangler secret put ' + rule.pass, { status: 503 });
      const hdr = request.headers.get('Authorization') || '';
      if (!hdr.startsWith('Basic ')) return deny(rule.realm);
      let user = '', pass = '';
      try { const dec = atob(hdr.slice(6)); const i = dec.indexOf(':'); user = dec.slice(0, i); pass = dec.slice(i + 1); } catch (e) { return deny(rule.realm); }
      if (!same(pass, want)) return deny(rule.realm);
      if (env[rule.user] && !same(user, env[rule.user])) return deny(rule.realm);
    }
    const res = await env.ASSETS.fetch(request);
    if (rule) { const r = new Response(res.body, res); r.headers.set('Cache-Control', 'private, no-store'); r.headers.set('X-Robots-Tag', 'noindex'); return r; }
    return res;
  }
};
